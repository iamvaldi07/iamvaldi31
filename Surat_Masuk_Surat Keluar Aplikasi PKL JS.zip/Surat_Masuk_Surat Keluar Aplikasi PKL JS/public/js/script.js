document.addEventListener('DOMContentLoaded', function() {
    const suratForm = document.getElementById('suratForm');
    const suratList = document.getElementById('suratList');

    // Fungsi untuk mendapatkan daftar surat
    function getSurat() {
        fetch('/api/surat')
            .then(response => response.json())
            .then(data => {
                suratList.innerHTML = '';
                data.forEach(surat => {
                    const li = document.createElement('li');
                    li.innerHTML = `
                        No. Surat: ${surat.no_surat} <br>
                        Jenis: ${surat.jenis} <br>
                        Nama: ${surat.nama} <br>
                        Tanggal: ${surat.tanggal} <br>
                        Perihal: ${surat.perihal} <br>
                        ${surat.file ? `<a href="/uploads/${surat.file}" target="_blank">Lihat Dokumen</a>` : ''}
                    `;
                    suratList.appendChild(li);
                });
            });
    }

    // Mendapatkan daftar surat saat halaman dimuat
    getSurat();

    // Menangani form submission
    suratForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(suratForm);

        fetch('/api/surat', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(result => {
            getSurat();
            suratForm.reset();
        });
    });
});
