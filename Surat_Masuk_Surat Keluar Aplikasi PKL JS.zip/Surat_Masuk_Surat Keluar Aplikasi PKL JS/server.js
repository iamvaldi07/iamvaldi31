const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const multer = require('multer');
const session = require('express-session');

const app = express();
const port = 3000;

// Middleware untuk menangani JSON dan data form
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true
}));

// Mengatur folder public untuk file statis
app.use(express.static(path.join(__dirname, 'public')));

// Middleware untuk menyajikan file dari folder uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Konfigurasi penyimpanan file menggunakan multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });

// Database setup
const db = new sqlite3.Database('./data/surat.db');

db.serialize(() => {
  // Hapus tabel surat jika ada
  db.run(`DROP TABLE IF EXISTS surat`, (err) => {
    if (err) {
      return console.error(err.message);
    }

    // Buat tabel surat dengan skema baru
    db.run(`
      CREATE TABLE surat (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        no_surat TEXT,
        jenis TEXT,
        nama TEXT,
        tanggal TEXT,
        perihal TEXT,
        file TEXT
      )
    `, (err) => {
      if (err) {
        return console.error(err.message);
      }
    });
  });

  // Buat tabel pengguna
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT,
      password TEXT
    )
  `, (err) => {
    if (err) {
      return console.error(err.message);
    }

    // Tambahkan pengguna default jika belum ada
    db.get('SELECT * FROM users WHERE username = ?', ['admin'], (err, row) => {
      if (err) {
        return console.error(err.message);
      }
      if (!row) {
        db.run(`
          INSERT INTO users (username, password) VALUES ('admin', 'password')
        `, (err) => {
          if (err) {
            return console.error(err.message);
          }
        });
      }
    });
  });
});

// Middleware untuk memeriksa apakah pengguna telah login
function checkAuth(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Route untuk halaman login
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

// API untuk menangani login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
    if (err) {
      return res.status(500).send('Internal Server Error');
    }
    if (row) {
      req.session.user = row;
      res.redirect('/');
    } else {
      res.status(401).send('Invalid Credentials');
    }
  });
});

// Route untuk halaman utama yang dilindungi
app.get('/', checkAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// API untuk mendapatkan semua surat
app.get('/api/surat', checkAuth, (req, res) => {
  db.all('SELECT * FROM surat', [], (err, rows) => {
    if (err) {
      throw err;
    }
    res.json(rows);
  });
});

// API untuk menambahkan surat baru
app.post('/api/surat', upload.single('file'), checkAuth, (req, res) => {
  const { no_surat, jenis, nama, tanggal, perihal } = req.body;
  const file = req.file ? req.file.filename : null;
  db.run('INSERT INTO surat (no_surat, jenis, nama, tanggal, perihal, file) VALUES (?, ?, ?, ?, ?, ?)', [no_surat, jenis, nama, tanggal, perihal, file], function (err) {
    if (err) {
      return console.error(err.message);
    }
    res.json({ id: this.lastID });
  });
});

// API untuk mengganti password
app.post('/change-password', checkAuth, (req, res) => {
  const { oldPassword, newPassword } = req.body;
  db.get('SELECT * FROM users WHERE id = ? AND password = ?', [req.session.user.id, oldPassword], (err, row) => {
    if (err) {
      return res.status(500).send('Internal Server Error');
    }
    if (row) {
      db.run('UPDATE users SET password = ? WHERE id = ?', [newPassword, req.session.user.id], function (err) {
        if (err) {
          return res.status(500).send('Internal Server Error');
        }
        res.send('Password berhasil diubah');
      });
    } else {
      res.status(401).send('Password lama tidak valid');
    }
  });
});

// Route untuk halaman ganti password
app.get('/change-password', checkAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'change-password.html'));
  });  

app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
